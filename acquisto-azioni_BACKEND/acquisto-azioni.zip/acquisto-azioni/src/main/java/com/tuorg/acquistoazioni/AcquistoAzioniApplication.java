package com.tuorg.acquistoazioni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AcquistoAzioniApplication {
  public static void main(String[] args) {
    SpringApplication.run(AcquistoAzioniApplication.class, args);
  }
}
